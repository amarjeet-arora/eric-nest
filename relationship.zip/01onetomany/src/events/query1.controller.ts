import { Body, Controller, Delete, Get, HttpCode, Logger, NotFoundException, Param, ParseIntPipe, Patch, Post } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Like, MoreThan, Repository } from "typeorm";
import { CreateEventDto } from './create-event.dto';
import { Event } from './event.entity';
import { UpdateEventDto } from "./update-event.dto";

@Controller('/query')
export class QueryController1 {
  private readonly logger = new Logger(QueryController1.name);

  constructor(
    @InjectRepository(Event)
    private readonly repository: Repository<Event>
  ) { }

  
  /* @Get(':id')
  async findOne(@Param('id', ParseIntPipe) id: number) {
     
    const event = await this.repository.findOne(id);

    if (!event) {
      throw new NotFoundException();
    }

    return event;
  } */



  /* @Get(':id')
  async findOne(@Param('id', ParseIntPipe) id: number) {
     
    const event = await this.repository.findOne(id,{
      loadEagerRelations:false
    });

    if (!event) {
      throw new NotFoundException();
    }

    return event;
  } */


  @Get('practice2')
  async practice2() {
    return await this.repository.findOne(
      1,
      { relations: ['attendees'] }
    );
  }

  
}